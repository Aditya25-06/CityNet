/* CityNet Optimizer - web UI (uses algorithms.js) */
"use strict";

const $ = id => document.getElementById(id);
const esc = s => String(s).replace(/[&<>"']/g, c => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
const PALETTE = ["var(--green)", "var(--blue)", "var(--amber)", "var(--purple)", "var(--cyan)", "var(--pink)"];
const GRAPH = buildGraph();
let runId = 0;                      // bumping this cancels any running animation

/* ---------- helpers ---------- */
function delay(ms) {
  const f = [2.2, 1.5, 1, 0.6, 0.3][Number($("speed").value) - 1];
  return new Promise(r => setTimeout(r, ms * f));
}
const log = (t, c = "") => { const l = $("log"); l.insertAdjacentHTML("beforeend", `<div class="${c}">${esc(t)}</div>`); l.scrollTop = l.scrollHeight; };
const clearLog = () => { $("log").innerHTML = ""; };
const status = t => { $("status").textContent = t; };
const pad = (s, n) => String(s).padEnd(n, " ");

/* ---------- map drawing ---------- */
function mapSVG({ hiEdges = [], rejEdges = [], hiNodes = [], color = "var(--green)", amb = null } = {}) {
  const hi = new Set(hiEdges.map(e => [...e].sort().join("|")));
  const rej = new Set(rejEdges.map(e => [...e].sort().join("|")));
  let s = `<svg viewBox="40 40 520 440" role="img" aria-label="Road network map">`;
  ROADS.forEach(([a, b, w]) => {
    const [x1, y1] = CITIES[a], [x2, y2] = CITIES[b], k = [a, b].sort().join("|");
    const cls = hi.has(k) ? "road hi" : rej.has(k) ? "road rej" : "road";
    s += `<line class="${cls}" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}" style="${hi.has(k) ? `stroke:${color}` : ""}"/>`;
  });
  ROADS.forEach(([a, b, w]) => {
    const [x1, y1] = CITIES[a], [x2, y2] = CITIES[b];
    s += `<text class="wlabel" x="${(x1 + x2) / 2}" y="${(y1 + y2) / 2 - 6}" text-anchor="middle">${w}</text>`;
  });
  for (const [n, [x, y]] of Object.entries(CITIES)) {
    const lit = hiNodes.includes(n);
    s += `<g class="city ${lit ? "lit" : ""}" data-city="${n}" style="color:${color}">
      <circle cx="${x}" cy="${y}" r="11" ${lit ? `style="fill:${color}"` : ""}><title>${n}</title></circle>
      <text x="${x}" y="${y + 28}">${n}</text></g>`;
  }
  if (amb) s += `<text class="amb" x="${CITIES[amb][0]}" y="${CITIES[amb][1] - 16}">&#128657;</text>`;
  return s + "</svg>";
}
const drawMap = o => { $("stage").innerHTML = mapSVG(o); };

/* ---------- control builders ---------- */
const selectHTML = (id, label, values, def) =>
  `<label for="${id}">${label}</label><select id="${id}">${values.map(v => `<option ${v === def ? "selected" : ""}>${v}</option>`).join("")}</select>`;

/* ====================================================================== */
/*  MODULES                                                               */
/* ====================================================================== */
const MODULES = [
  /* ---------- 1. Dijkstra ---------- */
  {
    title: "Emergency Route Finder",
    algo: "Dijkstra's shortest path (Greedy, min-heap) | O((V+E) log V)",
    init() {
      const names = Object.keys(CITIES).sort();
      $("controls").innerHTML =
        selectHTML("src", "Ambulance start city", names, "Ludhiana") +
        selectHTML("dst", "Hospital / destination city", names, "Amritsar") +
        `<div class="row"><button class="btn" id="go">&#9654; Find shortest route</button>
         <button class="btn blue sm" id="swap" title="Swap start and destination">&#8646;</button></div>
         <p class="hint">Tip: click two cities on the map to choose start and destination. Numbers on roads are distances in km.</p>`;
      drawMap();
      log("Pick two cities and press the button.", "m");
      let clicks = 0;
      $("stage").onclick = e => {
        const g = e.target.closest("[data-city]"); if (!g) return;
        $(clicks++ % 2 === 0 ? "src" : "dst").value = g.dataset.city;
      };
      $("swap").onclick = () => { const a = $("src").value; $("src").value = $("dst").value; $("dst").value = a; };
      $("go").onclick = () => this.run();
    },
    async run() {
      const my = ++runId, s = $("src").value, d = $("dst").value;
      clearLog();
      if (s === d) { log("Source and destination are the same.", "r"); status("Choose two different cities"); drawMap(); return; }
      const { dist, path, order } = dijkstra(GRAPH, s, d);
      log("Cities settled by Dijkstra (nearest first):", "b");
      order.forEach(([u, du]) => log(`  ${pad(u, 11)} ${du} km`));
      const edges = path.slice(1).map((p, i) => [path[i], p]);
      for (let i = 0; i <= edges.length; i++) {
        if (my !== runId) return;
        drawMap({ hiEdges: edges.slice(0, i), hiNodes: path.slice(0, i + 1), amb: path[i] });
        status(i < edges.length ? `Driving... ${path[i]}` : "");
        if (i < edges.length) await delay(520);
      }
      status(`Shortest distance: ${dist} km`);
      log("\nBest route:", "g"); log("  " + path.join(" -> "), "g"); log(`Total = ${dist} km`, "a");
    },
  },

  /* ---------- 2. MST ---------- */
  {
    title: "Optical-Fibre Network Planner",
    algo: "Kruskal (edge-based, union-find) & Prim (vertex-based, min-heap) | O(E log V)",
    init() {
      $("controls").innerHTML =
        selectHTML("mstAlgo", "Choose algorithm", ["Kruskal", "Prim"], "Kruskal") +
        `<button class="btn" id="go">&#9654; Build cheapest network</button>
         <p class="hint">Goal: connect ALL cities with minimum total cable. Green = cable laid, red dashed = rejected (would form a cycle).</p>`;
      drawMap(); $("stage").onclick = null;
      log("Goal: connect all cities with minimum cable length.", "m");
      $("go").onclick = () => this.run();
    },
    async run() {
      const my = ++runId, algo = $("mstAlgo").value;
      clearLog();
      const { total, steps } = algo === "Kruskal" ? kruskal(Object.keys(CITIES), ROADS) : prim(GRAPH, "Ludhiana");
      const full = ROADS.reduce((t, r) => t + r[2], 0);
      log(`${algo}'s algorithm - step log`, "b");
      if (algo === "Prim") log("Starting city: Ludhiana", "m");
      const chosen = [], rejected = [];
      for (const [a, b, w, ok] of steps) {
        if (my !== runId) return;
        (ok ? chosen : rejected).push([a, b]);
        log(`${ok ? "ADD   " : "SKIP  "}${a}-${b} (${w} km)`, ok ? "g" : "r");
        drawMap({ hiEdges: chosen, rejEdges: rejected, hiNodes: chosen.flat() });
        status(`Cable laid so far: ${chosen.length} links`);
        await delay(420);
      }
      if (my !== runId) return;
      status(`Minimum cable = ${total} km`);
      log(`\nMST cost : ${total} km`, "g"); log(`All roads: ${full} km`, "m");
      log(`Saved    : ${full - total} km (${(100 * (full - total) / full).toFixed(0)}%)`, "a");
    },
  },

  /* ---------- 3. Knapsack ---------- */
  {
    title: "Relief-Truck Loading",
    algo: "Fractional Knapsack (Greedy, sort by value/weight) | O(n log n)",
    init() {
      $("controls").innerHTML =
        `<label for="cap">Truck capacity (kg)</label>
         <input type="number" id="cap" min="1" max="400" value="120">
         <input type="range" id="capR" min="10" max="300" value="120">
         <button class="btn" id="go">&#9654; Load the truck</button>
         <p class="hint">Drag the slider to see the greedy choice change live.</p>`;
      $("stage").onclick = null;
      clearLog(); log("Items (weight kg / priority value):", "b");
      RELIEF_ITEMS.forEach(([n, w, v]) => log(`  ${pad(n, 13)}${String(w).padStart(3)} kg   ${v}`, "m"));
      const sync = from => { const v = $(from).value; $("cap").value = v; $("capR").value = v; this.run(); };
      $("cap").oninput = () => sync("cap"); $("capR").oninput = () => sync("capR");
      $("go").onclick = () => this.run();
      this.run();
    },
    run() {
      runId++;
      const cap = parseFloat($("cap").value);
      if (!(cap > 0)) { status("Enter a positive number"); return; }
      const { value, plan } = fractionalKnapsack(RELIEF_ITEMS, cap);
      clearLog(); log("Ranked by value / weight:", "b");
      const kg = x => +x.toFixed(2);                 // tidy kg numbers (no trailing zeros)
      let used = 0, segs = "", rows = "";
      log(`Truck capacity : ${kg(cap)} kg`, "m");
      plan.forEach((p, i) => {
        const taken = p.wt * p.frac; used += taken;
        const left = Math.max(0, cap - used);
        const col = PALETTE[i % 6], ratio = p.val / p.wt, pct = (p.frac * 100).toFixed(0);
        log(`${pad(p.name, 13)}r=${ratio.toFixed(2)}  take ${kg(taken)} kg (${pct}%)`, p.frac === 1 ? "g" : p.frac > 0 ? "a" : "r");
        log(`${" ".repeat(13)}remaining capacity: ${kg(left)} kg`, "m");
        if (taken > 0) segs += `<div data-w="${(taken / cap * 100).toFixed(3)}" style="background:${col};flex-basis:0" title="${esc(p.name)}: ${kg(taken)} kg">${taken / cap > 0.07 ? kg(taken) : ""}</div>`;
        const fc = p.frac === 1 ? "var(--green)" : p.frac > 0 ? "var(--amber)" : "var(--red)";
        rows += `<tr><td><span class="sw" style="background:${col}"></span>${esc(p.name)}</td>
          <td>${p.wt} kg</td>
          <td>${p.val}</td>
          <td>${ratio.toFixed(2)}</td>
          <td><div class="fillcell"><div class="meter"><i style="width:${p.frac * 100}%;background:${fc}"></i></div><b style="color:${fc}">${pct}%</b></div></td>
          <td style="color:${fc};font-weight:700">${kg(taken)} kg</td></tr>`;
      });
      const remaining = Math.max(0, cap - used);
      $("stage").innerHTML =
        `<h3 style="margin:6px 4px 12px">Truck capacity: ${kg(cap)} kg &nbsp;&middot;&nbsp; loaded ${kg(used)} kg &nbsp;&middot;&nbsp; remaining ${kg(remaining)} kg</h3>
         <div class="truck" id="truck">${segs}</div>
         <table class="tbl"><thead><tr><th>Item</th><th>Weight</th><th>Value</th><th>Value/Weight</th><th>Fill</th><th>Taken</th></tr></thead><tbody>${rows}</tbody></table>`;
      requestAnimationFrame(() => requestAnimationFrame(() =>
        $("truck") && $("truck").querySelectorAll("div").forEach(d => d.style.flexBasis = d.dataset.w + "%")));
      status(`Maximum total priority value = ${value.toFixed(1)}`);
      log(`\nLoaded    : ${kg(used)} kg`, "m");
      log(`Remaining : ${kg(remaining)} kg`, remaining > 0 ? "a" : "g");
      log(`Total value = ${value.toFixed(1)}`, "a");
    },
  },

  /* ---------- 4. Huffman ---------- */
  {
    title: "Emergency Message Compressor",
    algo: "Huffman coding (Greedy optimal tree, min-heap) | O(n log n)",
    init() {
      $("controls").innerHTML =
        `<label for="msg">Broadcast message (max 40 characters)</label>
         <input type="text" id="msg" maxlength="40" value="" placeholder="Type your message here" autocomplete="off">
         <button class="btn" id="go">&#9654; Compress with Huffman</button>`;
      $("stage").onclick = null;
      clearLog();
      $("stage").innerHTML = `<p class="hint" style="padding:30px;text-align:center;font-size:15px">Type a message and press Compress</p>`;
      $("go").onclick = () => this.run();
      $("msg").onkeydown = e => { if (e.key === "Enter") this.run(); };
      $("msg").focus();
    },
    run() {
      runId++;
      const text = $("msg").value.toUpperCase().slice(0, 40);
      clearLog();
      if (text.length < 2) { status("Type at least 2 characters"); $("stage").innerHTML = `<p class="hint" style="padding:20px">Type a message with at least 2 characters.</p>`; return; }
      const { root, codes, freq, order } = huffman(text);
      const bits = [...text].map(c => codes[c]).join("");
      if (huffmanDecode(bits, codes) !== text) { status("Internal decode check failed"); return; }
      const orig = 8 * text.length, comp = bits.length, saved = 100 * (orig - comp) / orig;
      const show = c => c === " " ? "␣" : c;           // visible symbol for the space character
      const maxF = Math.max(...Object.values(freq));

      /* tree layout */
      const leaves = []; (function col(n) { if (n.ch !== null) leaves.push(n); else { n.left && col(n.left); n.right && col(n.right); } })(root);
      const depthOf = n => !n ? 0 : 1 + Math.max(depthOf(n.left), depthOf(n.right));
      const D = depthOf(root), dy = 62, stepX = 46, W = Math.max(560, leaves.length * stepX + 40), H = D * dy + 40;
      const pos = new Map(); let idx = 0;
      (function layout(n, d) {
        if (n.ch !== null) { pos.set(n, [20 + stepX * (idx++ + 0.5), 32 + d * dy]); return; }
        const kids = [n.left, n.right].filter(Boolean);
        kids.forEach(k => layout(k, d + 1));
        pos.set(n, [kids.reduce((s, k) => s + pos.get(k)[0], 0) / kids.length, 32 + d * dy]);
      })(root, 0);
      let edges = "", nodes = "";
      (function draw(n) {
        const [x, y] = pos.get(n);
        [["0", n.left], ["1", n.right]].forEach(([b, k]) => {
          if (!k) return; const [kx, ky] = pos.get(k);
          edges += `<line class="tedge" x1="${x}" y1="${y}" x2="${kx}" y2="${ky}"/><text class="tbit" x="${(x + kx) / 2 + (b === "0" ? -9 : 9)}" y="${(y + ky) / 2}">${b}</text>`;
          draw(k);
        });
        if (n.ch !== null) nodes += `<g class="leaf fade"><rect x="${x - 16}" y="${y - 16}" width="32" height="32" rx="7"/><text class="ch" x="${x}" y="${y + 5}">${esc(show(n.ch))}</text><text class="fr" x="${x}" y="${y + 30}">${n.freq}</text></g>`;
        else nodes += `<g class="inode fade"><circle cx="${x}" cy="${y}" r="14"/><text x="${x}" y="${y + 4}">${n.freq}</text></g>`;
      })(root);

      /* ascending-frequency views */
      const bars = order.map(ch => `<div class="bar" title="${esc(show(ch))} : ${freq[ch]}"><em>${freq[ch]}</em><i style="height:${Math.max(8, freq[ch] / maxF * 100)}px"></i><span>${esc(show(ch))}</span></div>`).join("");
      const chips = order.map(ch => `<div class="code-chip"><b>${esc(show(ch))}</b> &times;${freq[ch]} &rarr; <u>${codes[ch]}</u></div>`).join("");

      $("stage").innerHTML = `<div class="hgrid">
        <div class="stats">
          <div class="stat"><b>${orig}</b><small>original bits (8 / char)</small></div>
          <div class="stat"><b style="color:var(--amber)">${comp}</b><small>Huffman bits</small></div>
          <div class="stat"><b style="color:var(--green)">${saved.toFixed(0)}%</b><small>space saved</small></div>
        </div>
        <div><p class="h-title">Letters in ascending order of frequency</p><div class="bars">${bars}</div></div>
        <div><p class="h-title">Letter &times; frequency &rarr; Huffman code (ascending frequency)</p><div class="chips">${chips}</div></div>
        <div><p class="h-title">Encoded message</p><div class="bitstream">${bits}</div></div>
        <div><p class="h-title">Huffman tree (left = 0, right = 1)</p><svg viewBox="0 0 ${W} ${H}" style="min-width:${Math.min(W, 560)}px">${edges}${nodes}</svg></div>
      </div>`;

      log("Letters in ascending order of frequency", "b");
      log("Char  Freq  Code", "b");
      order.forEach(ch => log(` ${pad(show(ch), 4)}  ${pad(freq[ch], 4)}  ${codes[ch]}`, "g"));
      log("\nOrder: " + order.map(c => `${show(c)}(${freq[c]})`).join(", "), "m");
      log(`\nOriginal   : ${orig} bits`, "m"); log(`Compressed : ${comp} bits`, "a"); log(`Saved      : ${saved.toFixed(0)}%`, "g");
      log("Decode check: OK", "g");
      status(`${orig} bits → ${comp} bits  (${saved.toFixed(0)}% smaller)`);
    },
  },

  /* ---------- 5. Benchmark ---------- */
  {
    title: "Sorting Benchmark",
    algo: "Bubble O(n²) vs Merge O(n log n) vs Quick O(n log n) average",
    init() {
      $("controls").innerHTML =
        `<button class="btn" id="go">&#9654; Run benchmark</button>
         <p class="hint">Sorts random lists of growing size and measures real running time. This verifies the Big-Oh notations from Unit 1 experimentally.</p>`;
      $("stage").onclick = null;
      $("stage").innerHTML = `<p class="hint" style="padding:30px;text-align:center;font-size:15px">Press &ldquo;Run benchmark&rdquo;</p>`;
      clearLog(); log("Ready.", "m");
      $("go").onclick = () => this.run();
    },
    async run() {
      const my = ++runId, sizes = [1000, 2000, 3000, 4000, 5000];
      const algos = [["Bubble", bubbleSort, "var(--red)"], ["Merge", mergeSort, "var(--blue)"], ["Quick", quickSort, "var(--green)"]];
      const times = { Bubble: [], Merge: [], Quick: [] };
      clearLog(); log(`${"n".padStart(6)}${"Bubble".padStart(9)}${"Merge".padStart(9)}${"Quick".padStart(9)}`, "b");
      status("Running...");
      for (const n of sizes) {
        await delay(30); if (my !== runId) return;
        const data = Array.from({ length: n }, () => 1 + Math.floor(Math.random() * 1e6));
        const ref = data.slice().sort((a, b) => a - b); let row = String(n).padStart(6);
        for (const [name, fn] of algos) {
          fn(data);                                   // warm-up run (lets the JS engine optimise)
          let ms = Infinity, res;
          for (let r = 0; r < 3; r++) {               // best of 3 runs = less noisy
            const t = performance.now(); res = fn(data); ms = Math.min(ms, performance.now() - t);
          }
          if (res.some((v, i) => v !== ref[i])) { log(`${name} produced a wrong result!`, "r"); return; }
          times[name].push(ms); row += ms.toFixed(1).padStart(9);
        }
        log(row);
      }
      const L = 70, B = 400, T = 80, R = 590, peak = Math.max(...Object.values(times).flat()) || 1;
      let s = `<svg viewBox="0 0 640 470"><text x="20" y="28" style="fill:var(--txt);font-size:17px;font-weight:700">Running time vs input size (ms)</text>`;
      for (let k = 0; k <= 4; k++) { const y = B - k * (B - T) / 4; s += `<line x1="${L}" y1="${y}" x2="${R}" y2="${y}" style="stroke:var(--line)"/><text x="${L - 8}" y="${y + 4}" text-anchor="end" style="fill:var(--muted);font-size:11px">${(peak * k / 4).toFixed(0)}</text>`; }
      const xs = sizes.map((_, i) => L + 25 + i * (R - L - 50) / (sizes.length - 1));
      sizes.forEach((n, i) => s += `<text x="${xs[i]}" y="${B + 20}" text-anchor="middle" style="fill:var(--muted);font-size:11px">${n}</text>`);
      s += `<text x="${(L + R) / 2}" y="${B + 44}" text-anchor="middle" style="fill:var(--muted);font-size:12px">n (number of elements)</text>`;
      algos.forEach(([name, , col], li) => {
        const pts = times[name].map((t, i) => [xs[i], B - t / peak * (B - T)]);
        s += `<polyline fill="none" stroke-width="3.5" stroke-linejoin="round" style="stroke:${col}" points="${pts.map(p => p.join(",")).join(" ")}"/>`;
        pts.forEach(p => s += `<circle cx="${p[0]}" cy="${p[1]}" r="4.5" style="fill:${col}"/>`);
        s += `<rect x="${330 + li * 90}" y="42" width="13" height="13" rx="3" style="fill:${col}"/><text x="${350 + li * 90}" y="53" style="fill:var(--txt);font-size:13px">${name}</text>`;
      });
      $("stage").innerHTML = s + "</svg>";
      const k = sizes.length - 1;
      status(`At n = ${sizes[k]}: Bubble is ${(times.Bubble[k] / Math.max(times.Merge[k], 0.001)).toFixed(0)}x slower than Merge`);
    },
  },
];

/* ====================================================================== */
/*  NAVIGATION, THEME                                                     */
/* ====================================================================== */
function openModule(i) {
  runId++;
  const m = MODULES[i];
  document.querySelectorAll("#nav button").forEach((b, k) => b.classList.toggle("active", k === i));
  $("modTitle").textContent = m.title; $("modAlgo").textContent = m.algo;
  status(""); clearLog(); $("stage").onclick = null;
  m.init.call(m);
  try { localStorage.setItem("citynet.mod", i); } catch (e) { /* ignore */ }
}
$("nav").addEventListener("click", e => { const b = e.target.closest("button[data-mod]"); if (b) openModule(+b.dataset.mod); });
$("clearLog").onclick = clearLog;
$("themeBtn").onclick = () => {
  const r = document.documentElement, t = r.dataset.theme === "light" ? "dark" : "light";
  r.dataset.theme = t; try { localStorage.setItem("citynet.theme", t); } catch (e) { /* ignore */ }
};
try { const t = localStorage.getItem("citynet.theme"); if (t) document.documentElement.dataset.theme = t; } catch (e) { /* ignore */ }
let startMod = 0; try { startMod = Math.min(4, Math.max(0, +localStorage.getItem("citynet.mod") || 0)); } catch (e) { /* ignore */ }
openModule(startMod);
