/* CityNet Optimizer - pure algorithm code (no DOM), shared by the browser UI and node tests */

const CITIES = {            // name : [x, y, population in lakh - approximate]
  "Amritsar":   [110, 80, 11.3],
  "Jalandhar":  [225, 165, 8.7],
  "Hoshiarpur": [345, 135, 1.7],
  "Chandigarh": [500, 105, 10.6],
  "Ferozepur":  [90, 290, 1.1],
  "Moga":       [205, 300, 1.6],
  "Ludhiana":   [330, 265, 16.2],
  "Patiala":    [490, 295, 4.5],
  "Sangrur":    [385, 385, 0.9],
  "Bathinda":   [210, 435, 2.9],
};
const ROADS = [
  ["Amritsar", "Jalandhar", 80], ["Amritsar", "Ferozepur", 115],
  ["Jalandhar", "Hoshiarpur", 40], ["Jalandhar", "Ludhiana", 62],
  ["Jalandhar", "Moga", 85], ["Hoshiarpur", "Chandigarh", 100],
  ["Ludhiana", "Chandigarh", 100], ["Ludhiana", "Moga", 62],
  ["Ludhiana", "Patiala", 110], ["Ludhiana", "Sangrur", 80],
  ["Moga", "Ferozepur", 45], ["Moga", "Bathinda", 80],
  ["Patiala", "Chandigarh", 65], ["Patiala", "Sangrur", 50],
  ["Sangrur", "Bathinda", 90], ["Patiala", "Bathinda", 90],
  ["Ferozepur", "Bathinda", 120],
];
const RELIEF_ITEMS = [      // name, weight (kg), priority value
  ["Medicines", 10, 300], ["Food packets", 40, 280], ["Tents", 60, 240],
  ["Blankets", 30, 150], ["Water cans", 50, 100], ["Generators", 80, 320],
];

/* ---------- small binary min-heap ---------- */
class MinHeap {
  constructor(less) { this.a = []; this.less = less; }
  get size() { return this.a.length; }
  push(x) {
    const a = this.a; a.push(x);
    let i = a.length - 1;
    while (i > 0) {
      const p = (i - 1) >> 1;
      if (this.less(a[i], a[p])) { [a[i], a[p]] = [a[p], a[i]]; i = p; } else break;
    }
  }
  pop() {
    const a = this.a, top = a[0], last = a.pop();
    if (a.length) {
      a[0] = last;
      let i = 0;
      for (;;) {
        let l = 2 * i + 1, r = l + 1, m = i;
        if (l < a.length && this.less(a[l], a[m])) m = l;
        if (r < a.length && this.less(a[r], a[m])) m = r;
        if (m === i) break;
        [a[i], a[m]] = [a[m], a[i]]; i = m;
      }
    }
    return top;
  }
}

function buildGraph() {
  const g = {};
  Object.keys(CITIES).forEach(c => g[c] = []);
  ROADS.forEach(([a, b, w]) => { g[a].push([b, w]); g[b].push([a, w]); });
  return g;
}

/* Dijkstra - greedy single-source shortest path, O((V+E) log V) */
function dijkstra(graph, src, dst) {
  const dist = {}; Object.keys(graph).forEach(v => dist[v] = Infinity);
  const prev = {}; dist[src] = 0;
  const pq = new MinHeap((p, q) => p[0] < q[0]); pq.push([0, src]);
  const order = [];
  while (pq.size) {
    const [d, u] = pq.pop();
    if (d > dist[u]) continue;
    order.push([u, d]);
    if (u === dst) break;
    for (const [v, w] of graph[u]) {
      if (d + w < dist[v]) { dist[v] = d + w; prev[v] = u; pq.push([d + w, v]); }
    }
  }
  const path = []; let node = dst;
  while (node !== src && node in prev) { path.push(node); node = prev[node]; }
  path.push(src);
  return { dist: dist[dst], path: path.reverse(), order };
}

class DisjointSet {
  constructor(items) { this.p = {}; items.forEach(i => this.p[i] = i); }
  find(x) {
    while (this.p[x] !== x) { this.p[x] = this.p[this.p[x]]; x = this.p[x]; }
    return x;
  }
  union(a, b) {
    const ra = this.find(a), rb = this.find(b);
    if (ra === rb) return false;
    this.p[ra] = rb; return true;
  }
}

/* Kruskal - sort edges, keep the cheapest that makes no cycle, O(E log E) */
function kruskal(nodes, edges) {
  const ds = new DisjointSet(nodes), steps = []; let total = 0;
  [...edges].sort((x, y) => x[2] - y[2]).forEach(([a, b, w]) => {
    const ok = ds.union(a, b);
    if (ok) total += w;
    steps.push([a, b, w, ok]);
  });
  return { total, steps };
}

/* Prim - grow a tree from `start`, always add the cheapest crossing edge */
function prim(graph, start) {
  const seen = new Set([start]), steps = []; let total = 0;
  const pq = new MinHeap((p, q) => p[0] < q[0]);
  graph[start].forEach(([v, w]) => pq.push([w, start, v]));
  const n = Object.keys(graph).length;
  while (pq.size && seen.size < n) {
    const [w, u, v] = pq.pop();
    if (seen.has(v)) continue;
    seen.add(v); total += w; steps.push([u, v, w, true]);
    graph[v].forEach(([x, wx]) => { if (!seen.has(x)) pq.push([wx, v, x]); });
  }
  return { total, steps };
}

/* Fractional knapsack - greedy by value/weight ratio, O(n log n) */
function fractionalKnapsack(items, capacity) {
  const ranked = [...items].sort((a, b) => b[2] / b[1] - a[2] / a[1]);
  let left = capacity, value = 0; const plan = [];
  for (const [name, wt, val] of ranked) {
    if (left <= 0) { plan.push({ name, wt, val, frac: 0 }); continue; }
    const take = Math.min(wt, left), frac = take / wt;
    plan.push({ name, wt, val, frac });
    value += val * frac; left -= take;
  }
  return { value, plan };
}

/* sorting algorithms */
function bubbleSort(arr) {
  const a = arr.slice(), n = a.length;
  for (let i = 0; i < n - 1; i++) {
    let swapped = false;
    for (let j = 0; j < n - 1 - i; j++) {
      if (a[j] > a[j + 1]) { const t = a[j]; a[j] = a[j + 1]; a[j + 1] = t; swapped = true; }
    }
    if (!swapped) break;
  }
  return a;
}
function mergeSort(a) {
  if (a.length <= 1) return a.slice();
  const mid = a.length >> 1, l = mergeSort(a.slice(0, mid)), r = mergeSort(a.slice(mid));
  const out = []; let i = 0, j = 0;
  while (i < l.length && j < r.length) out.push(l[i] <= r[j] ? l[i++] : r[j++]);
  while (i < l.length) out.push(l[i++]);
  while (j < r.length) out.push(r[j++]);
  return out;
}
function quickSort(a) {
  if (a.length <= 1) return a.slice();
  const pivot = a[a.length >> 1];
  return quickSort(a.filter(x => x < pivot))
    .concat(a.filter(x => x === pivot), quickSort(a.filter(x => x > pivot)));
}

/* Huffman coding - repeatedly merge the two least frequent nodes, O(n log n)
   Returns letters ALSO arranged in ascending order of frequency (ties alphabetical). */
function huffman(text) {
  const freq = {};
  for (const ch of text) freq[ch] = (freq[ch] || 0) + 1;
  let uid = 0;
  const heap = new MinHeap((p, q) => p.freq < q.freq || (p.freq === q.freq && p.id < q.id));
  // seed the heap in ascending (freq, char) order so ties are deterministic
  const order = Object.keys(freq).sort((a, b) => freq[a] - freq[b] || (a < b ? -1 : 1));
  order.forEach(ch => heap.push({ freq: freq[ch], ch, left: null, right: null, id: uid++ }));
  if (heap.size === 1) {
    const only = heap.pop();
    heap.push({ freq: only.freq, ch: null, left: only, right: null, id: uid++ });
  }
  while (heap.size > 1) {
    const a = heap.pop(), b = heap.pop();
    heap.push({ freq: a.freq + b.freq, ch: null, left: a, right: b, id: uid++ });
  }
  const root = heap.pop(), codes = {};
  (function walk(n, code) {
    if (n.ch !== null) { codes[n.ch] = code || "0"; return; }
    if (n.left) walk(n.left, code + "0");
    if (n.right) walk(n.right, code + "1");
  })(root, "");
  return { root, codes, freq, order };
}

function huffmanDecode(bits, codes) {
  const inv = {}; Object.entries(codes).forEach(([k, v]) => inv[v] = k);
  let out = "", buf = "";
  for (const b of bits) { buf += b; if (buf in inv) { out += inv[buf]; buf = ""; } }
  return out;
}

if (typeof module !== "undefined") {
  module.exports = { CITIES, ROADS, RELIEF_ITEMS, buildGraph, dijkstra, kruskal, prim,
    fractionalKnapsack, bubbleSort, mergeSort, quickSort, huffman, huffmanDecode };
}
