#!/bin/sh
# Open CityNet Optimizer (web version) in Google Chrome.  Mac / Linux:  sh open_web.sh
PAGE="$(cd "$(dirname "$0")" && pwd)/web/index.html"
if [ "$(uname)" = "Darwin" ]; then
  open -a "Google Chrome" "$PAGE" 2>/dev/null || open "$PAGE"
else
  for c in google-chrome google-chrome-stable chromium chromium-browser; do
    if command -v "$c" >/dev/null 2>&1; then "$c" "$PAGE" >/dev/null 2>&1 & exit 0; fi
  done
  xdg-open "$PAGE"
fi
