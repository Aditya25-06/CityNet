@echo off
rem Double-click this file to open CityNet Optimizer (web version) in Google Chrome.
set "PAGE=%~dp0web\index.html"

rem 1) Chrome in its usual install locations
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" "%PAGE%" & exit /b
)
if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" "%PAGE%" & exit /b
)
if exist "%LocalAppData%\Google\Chrome\Application\chrome.exe" (
    start "" "%LocalAppData%\Google\Chrome\Application\chrome.exe" "%PAGE%" & exit /b
)

rem 2) Chrome registered with Windows
start "" chrome "%PAGE%" 2>nul && exit /b

rem 3) Fallback: default browser
start "" "%PAGE%"
